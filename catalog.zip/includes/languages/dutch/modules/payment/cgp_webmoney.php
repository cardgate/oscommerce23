<?php
/**
 * $Id: cgp_webmoney.php 30 2011-12-23 17:35:13Z h0ax $
 *
 * osCommerce, Open Source E-Commerce Solutions
 * http://www.oscommerce.com
 *
 * Copyright (c) 2002 osCommerce
 *
 * Released under the GNU General Public License
 *
 * Created by BZ (support@cardgateplus.com)
 * version 2.10 2010-06-21
 */
require_once("cgp_generic.php");
?>