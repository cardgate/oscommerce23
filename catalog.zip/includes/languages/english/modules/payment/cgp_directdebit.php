<?php
/**
 * $Id: cgp_directdebit.php 30 2011-12-23 17:35:13Z h0ax $
 *
 * osCommerce, Open Source E-Commerce Solutions
 * http://www.oscommerce.com
 *
 * Copyright (c) 2002 osCommerce
 *
 * Released under the GNU General Public License
 *
 * Created by BZ (support@cardgateplus.com)
 * version 2.20 2011-02-14
 */
require_once("cgp_generic.php");
?>
